from .window   import Window, InstrState
from .program  import Process, _program
from .cache    import Cache
from .         import exec_graph as ex
import json

global _scheduler

class Scheduler:

    def __init__(self) -> None:
        self.iterations = 0
        self.window_size= 1
        self.dispWidth  = 1
        self.retrWidth  = 1
        self.sched      = "optimal"
        self.blkSize    = 1
        self.nBlocks    = 1
        self.mPenalty   = 0
        self.mIssueTime = 0
        self.port_mask  = 0
        self.n_ports    = 0
        self.cache      = None
        self.window     = Window(1)
        self.num_instr  = 0
        self.n          = 0
        self.dispatched = 0
        self.pc         = 0
        self.cycles     = 0
        self.DepEdges   = []

    def next_cycle(self) -> int:

        xw    = self.n_ports
        rw    = self.retrWidth
        sched = self.sched != "greedy"

        issue_queue = {}
        used_ports  = {port:False for port in range(32) if (self.port_mask >> port) & 1}
        ReadMisses  = []
        SecondMisses= []
        WriteMisses = []
        MMupdates   = []

        for window_idx in range(self.window.count):

            instr       = self.window[window_idx]
            static_idx  = instr.s_idx
            dynamic_idx = instr.d_idx

            if instr.state == InstrState.WRITE_BACK:
                if rw:
                    if window_idx == 0 or self.window[window_idx-1].state == InstrState.RETIRE:
                        instr.state    = InstrState.RETIRE
                        instr.substate = InstrState.NONE
                        rw -= 1
                    else:
                        instr.substate = InstrState.WAIT_RETIRE
                else:
                    instr.substate = InstrState.WAIT_RETIRE

            elif instr.state == InstrState.LOAD or instr.state == InstrState.STORE:
                instr.latency -= 1
                if instr.latency == 0:
                    if instr.substate == InstrState.WAIT_DATA_READY or instr.substate == InstrState.WAIT_CACHE_2ND or self.cache is None:
                        instr.state    = InstrState.WRITE_BACK
                        instr.substate = InstrState.NONE
                    elif instr.substate == InstrState.MM_UPDATE:
                        instr.substate = InstrState.WAIT_DATA_READY
                        instr.latency = self.mPenalty - self.mIssueTime - 1
                        instr.exec_lat += self.mPenalty                    
                    elif instr.substate == InstrState.WAIT_MM_READY:
                        instr.substate = InstrState.WAIT_DATA_READY
                        instr.latency = self.mPenalty - self.mIssueTime
                        instr.exec_lat += self.mPenalty
                    elif instr.substate == InstrState.WAIT_MM_RDY_UPDT:
                        instr.substate = InstrState.MM_UPDATE
                        instr.latency = 1
                    elif instr.substate == InstrState.WAIT_MM_REQUEST:
                        instr.substate = InstrState.WAIT_MM_READY
                        instr.latency = self.mIssueTime
                    elif instr.substate == InstrState.WAIT_MM_REQ_UPDT:
                        instr.substate = InstrState.WAIT_MM_RDY_UPDT
                        instr.latency = self.mIssueTime
                    else:
                        result, instr.latency = self.cache.access(instr.memory-1, instr.memAddr, self.cycles)
                        instr.exec_lat += instr.latency   # add extra latency in case of cache miss
                        if result == 0:  # HIT
                            instr.state    = InstrState.WRITE_BACK
                            instr.substate = InstrState.NONE
                        elif result == 1:  # Primary miss
                            if instr.memory == 1:
                                ReadMisses.append(instr.d_idx)
                            else:                       
                                WriteMisses.append(instr.d_idx)
                            if instr.latency > 0:
                                instr.substate = InstrState.WAIT_MM_REQUEST
                            else:
                                instr.substate = InstrState.WAIT_MM_READY
                                instr.latency = self.mIssueTime
                        elif result == 3:  # Primary miss with MM update of dirty block
                            if instr.memory == 1:
                                ReadMisses.append(instr.d_idx)
                            else:                       
                                WriteMisses.append(instr.d_idx)
                            MMupdates.append(instr.d_idx)
                            if instr.latency > 0:
                                instr.substate = InstrState.WAIT_MM_REQ_UPDT
                            else:
                                instr.substate = InstrState.WAIT_MM_RDY_UPDT
                                instr.latency = self.mIssueTime
                        else:  # Secondary miss
                            SecondMisses.append(instr.d_idx)
                            instr.substate = InstrState.WAIT_CACHE_2ND

            elif instr.state == InstrState.EXECUTE:
                instr.latency -= 1
                if instr.latency == 0:
                    instr.state    = InstrState.WRITE_BACK
                    instr.substate = InstrState.NONE

            elif instr.state == InstrState.DISPATCH:
                if instr.substate in [InstrState.NONE, InstrState.WAIT_DATA]:
                    instr.substate = InstrState.NONE
                  
                    for dependence_offset in self.DepEdges[static_idx]:
                        instr_dep = self.window.get_instr( dynamic_idx - dependence_offset )
                        if not instr_dep: # instruction is no longer in the window
                            continue
                        else:
                            if instr_dep.state not in [InstrState.WRITE_BACK, InstrState.RETIRE]:
                                instr.substate = InstrState.WAIT_DATA
                                break

                if instr.substate != InstrState.WAIT_DATA:
                    port_mask = _program.instruction_list[static_idx].ports
                    latency   = _program.instruction_list[static_idx].latency
                    required_ports= [port for port in range(32) if (port_mask >> port) & 1]
                    if not sched:  # Greedy scheduling algorithm
                      if xw:
                        for port in required_ports:
                            if not used_ports[port]:
                                used_ports[port] = True
                                instr.exec_cycle = self.cycles
                                instr.latency    = latency
                                instr.exec_lat  += latency
                                if instr.memory > 0:
                                    instr.state = InstrState.LOAD if instr.memory == 1 else InstrState.STORE
                                else:
                                    instr.state = InstrState.EXECUTE
                                instr.substate   = InstrState.NONE
                                instr.port_used  = port
                                xw -= 1
                                break
                        if instr.state == InstrState.DISPATCH:
                            instr.substate  = InstrState.WAIT_RESOURCE
                            instr.exec_lat += 1
                      else:
                        instr.substate  = InstrState.WAIT_BANDWIDTH
                        instr.exec_lat += 1

                    else:   # Optimal scheduling: first priority is age, second is using most ports
                      issue_queue[window_idx] = required_ports
                      instr.latency           = latency

            elif instr.state != InstrState.RETIRE:
                print("ERROR")


        if sched:  # Improved scheduling algorithm
            issd_isps = ex.old_priority(issue_queue)
            for w_idx in issue_queue:
              instr          = self.window[w_idx]
              instr.substate = InstrState.NONE
              if xw:
                  if w_idx in issd_isps:
                    port             = issd_isps[w_idx]
                    instr.port_used  = port
                    used_ports[port] = True
                    instr.exec_cycle = self.cycles
                    if instr.memory > 0:
                        instr.state = InstrState.LOAD if instr.memory == 1 else InstrState.STORE
                    else:
                        instr.state = InstrState.EXECUTE                      
                    instr.exec_lat  += instr.latency
                    xw -= 1
                  else:
                    instr.substate  = InstrState.WAIT_RESOURCE
                    instr.exec_lat += 1
              else:
                  instr.substate  = InstrState.WAIT_BANDWIDTH
                  instr.exec_lat += 1

        retires = self.retrWidth - rw
        return retires, used_ports, ReadMisses, SecondMisses, WriteMisses, MMupdates

    def dispatch(self):
        dw = self.dispWidth
        while self.dispatched < self.n and dw and not self.window.is_full():
            static_idx = self.pc % self.num_instr
            instr_mem  = 0
            addr       = -1
            instr      = _program[static_idx]
            if instr.type == "MEM" or instr.type == "VMEM":
                instr_mem  = 1 if instr.oper == "LOAD" else 2
                addr       = instr.addr
                instr.addr = addr + instr.byte_stride
    
            self.window.push(self.cycles, self.pc, static_idx, instr_mem, addr)
            self.pc += 1
            dw      -= 1
            self.dispatched +=1

        self.cycles += 1

    def generate_timeline_state ( self, dynamic_idx, stages, critical_path):
        
        criticalList = []

        # Decode Stage
        decode_stage = "D"
        stages.pop(0)

        if len(critical_path) > 0:
          node = critical_path[-1]
          idx  = node[0] // 3
          stage= node[0] % 3
          if idx == dynamic_idx and stage == 0:
            if node[1] == 1:
                criticalList.append(0)  # Decode stage is in critical path
            critical_path.pop(-1)

        cycle = 1
        while stages[0] == InstrState.WAIT_DATA:
            decode_stage += stages[0].value
            stages.pop(0)
            cycle = cycle+1
        
        # Execute Stage
        execute_stage = ""
        count = 0

        if len(critical_path) > 0:
          node = critical_path[-1]
          idx  = node[0] // 3
          stage= node[0] % 3
          if idx == dynamic_idx and stage == 1:
            count = node[1]-1
            criticalList.append(cycle)  # Execute stage is in critical path
            critical_path.pop(-1)
        
        while stages[0] != InstrState.RETIRE:
            execute_stage += stages[0].value
            stages.pop(0)
            cycle = cycle+1
            if count > 0:
                count = count-1
                criticalList.append(cycle)  # Execute stage is in critical path
        
        # Retire Stage
        retire_stage = "R"
        if len(critical_path) > 0:
          node = critical_path[-1]
          idx  = node[0] // 3
          stage= node[0] % 3
          if idx == dynamic_idx and stage == 2:
              critical_path.pop(-1)
              if node[1] == 1:
                criticalList.append(cycle)  # Execute stage is in critical path

        return (decode_stage + execute_stage + retire_stage, criticalList)

    def generate_timeline(self, ports):
        rw              = self.retrWidth
        retired         = 0
        self.dispatched = 0
        self.cycles     = 0
        last_ret_cycle  = 0
        last_disp_cycle = 0

        timeline      = {i:[] for i in range(self.n + self.window.size + rw)}
        port_timeline = {port:[] for port in ports}
        INSTR_Info    = []

        ExecGraph     = ex.generate_execution_graph( self.num_instr, self.n, self.window_size, self.DepEdges )

        while retired < self.n:
            retires, used_ports, _,_,_,_ = self.next_cycle()

            for port, used in used_ports.items():
                port_timeline[port].append(used)

            for i in range(retires):
                r_instr     = self.window[i]
                dynamic_idx = r_instr.d_idx
                if dynamic_idx != retired:
                    print("ERROR\n")

                disp_latency    = r_instr.disp_cycle - last_disp_cycle
                last_disp_cycle = r_instr.disp_cycle
                ret_latency     = self.cycles - last_ret_cycle
                last_ret_cycle  = self.cycles
                exec_latency    = r_instr.exec_lat

                INSTR_Info.append([r_instr.exec_cycle, r_instr.port_used, r_instr.memAddr])

                timeline[ dynamic_idx ].append((self.cycles, r_instr.state))

                ex.exec_graph_update ( ExecGraph, dynamic_idx, disp_latency, exec_latency, ret_latency ) 

                retired += 1
                if retired >= self.n:
                    break

            self.window.pop(retires)
            self.dispatch()

            for instr in self.window:
                if instr.substate != InstrState.NONE:
                    timeline[instr.d_idx].append((self.cycles, instr.substate))
                else:
                    timeline[instr.d_idx].append((self.cycles, instr.state))

        critical_path = ex.longest_path(ExecGraph)

        return timeline, port_timeline, INSTR_Info, critical_path

    def get_timeline(self, processJSON, niters: int = 3) -> str:

        process = Process.from_json(processJSON)
        _program.load_instruction_list(process.instruction_list)

        self.iterations = niters
        self.window_size= process.ROBsize
        self.window     = Window(process.ROBsize)
        self.DepEdges   = _program.dependence_edges
        self.dispWidth  = process.dispatch
        self.retrWidth  = process.retire
        self.mPenalty   = process.mPenalty
        self.mIssueTime = process.mIssueTime
        self.sched      = process.sched
        self.blkSize    = process.blkSize
        self.nBlocks    = process.nBlocks

        _program.assign_memory_addresses(self.iterations)
        
        # Always creat a new cache object to reset cache state, even if nBlocks is 0 (no cache)
        if self.nBlocks > 0:
            self.cache  = Cache(self.nBlocks, self.blkSize, self.mPenalty, self.mIssueTime)
        else:
            self.cache = None
            
        self.num_instr  = _program.n
        self.n          = niters*self.num_instr
        self.pc         = 0
        self.cycles     = 0
        self.dispatched = 0

        all_ports = 0
        for instr in _program.instruction_list:
            all_ports |= instr.ports
        self.port_mask = all_ports

        # list of used ports and number of used ports
        ports        = [i for i in range(32) if (all_ports >> i) & 1]
        self.n_ports = len(ports)

        timeline, _, INSTR_Info, critical_path = self.generate_timeline(ports) 

        instructions = []    # List of timeline.instructions

        for i, cycles in timeline.items():

            if not cycles or i >= self.n:
                break

            stages, criticalList = self.generate_timeline_state( i, [s for _,s in cycles], critical_path)

            instr = [
                i // self.num_instr,   # loop iteration
                i % self.num_instr,    # instruction Index
                cycles[0][0]-1,        # starting cycle
                INSTR_Info[i][1],      # port
                stages,                # states
                criticalList,          # critical states
                INSTR_Info[i][2]       # memory address
            ]
            instructions.append(instr)   # insert new instruction in timeline structure

        timelineJson                 = {}
        timelineJson["cycles"]       = self.cycles
        timelineJson["instructions"] = instructions
        timelineJson["arrays"]       = _program.arrays

        return json.dumps(timelineJson)

    def get_results(self, processJSON, niters: int = 3) -> str:

        process = Process.from_json(processJSON)
        _program.load_instruction_list(process.instruction_list)

        self.iterations = niters
        self.window_size= process.ROBsize
        self.window     = Window(process.ROBsize)
        self.DepEdges   = _program.dependence_edges
        self.dispWidth  = process.dispatch
        self.retrWidth  = process.retire
        self.mPenalty   = process.mPenalty
        self.mIssueTime = process.mIssueTime
        self.sched      = process.sched
        self.blkSize    = process.blkSize
        self.nBlocks    = process.nBlocks

        _program.assign_memory_addresses(self.iterations)
        
        if self.nBlocks > 0:
            self.cache  = Cache(self.nBlocks, self.blkSize, self.mPenalty, self.mIssueTime)
        else:
            self.cache = None

        self.num_instr  = _program.n
        self.n          = niters*self.num_instr
        self.pc         = 0
        self.cycles     = 0
        self.dispatched = 0

        retired         = 0
        last_ret_cycle  = 0
        last_disp_cycle = 0
        MM_writes, Reads, RdMisses, Writes, WrMisses, S2Misses = 0, 0, 0, 0, 0, 0

        all_ports = 0
        for instr in _program.instruction_list:
            all_ports |= instr.ports
        self.port_mask = all_ports

        # list of used ports and number of used ports
        ports        = [i for i in range(32) if (all_ports >> i) & 1]
        self.n_ports = len(ports)
        port_usage   = {port:0 for port in ports}

        ExecGraph  = ex.generate_execution_graph( self.num_instr, self.n, self.window_size, self.DepEdges )

        while retired < self.n:
            retires, used_ports, ReadMisses, SecondMisses, WriteMisses, MMupdates = self.next_cycle()

            for idx in ReadMisses:
                if idx < self.n:
                    RdMisses += 1

            for idx in WriteMisses:
                if idx < self.n:
                    WrMisses += 1

            for idx in MMupdates:
                if idx < self.n:
                    MM_writes += 1

            for idx in SecondMisses:
                if idx < self.n:
                    S2Misses += 1

            for port in ports:
                if used_ports[port]:
                   port_usage[port] += 1

            for i in range(retires):
                r_instr     = self.window[i]
                dynamic_idx = r_instr.d_idx
                if dynamic_idx != retired:
                    print("ERROR\n")

                disp_latency    = r_instr.disp_cycle - last_disp_cycle
                last_disp_cycle = r_instr.disp_cycle
                ret_latency     = self.cycles - last_ret_cycle
                last_ret_cycle  = self.cycles
                exec_latency    = r_instr.exec_lat
                ex.exec_graph_update ( ExecGraph, dynamic_idx, disp_latency, exec_latency, ret_latency )

                if r_instr.memory != 0:  # LOAD or STORE
                    if r_instr.memory == 1:  # LOAD
                        Reads += 1
                    elif r_instr.memory == 2:  # STORE
                        Writes += 1

                retired += 1
                if retired >= self.n:
                    break

            self.window.pop(retires)
            self.dispatch()

        critical_path   = ex.longest_path(ExecGraph)
        cycles_per_iter = self.cycles / self.iterations
        IPC             = self.n      / self.cycles

        out = {}
        out["total_iterations"]     = self.iterations
        out["total_instructions"]   = self.n
        out["total_cycles"]         = self.cycles
        out["ipc"]                  = IPC
        out["cycles_per_iteration"] = cycles_per_iter
        out["ports"] = {}
        for port in ports:
           usage = port_usage[port]/self.cycles
           out["ports"][str(port)] = usage*100

        out["reads"]          = Reads
        out["read_misses"]    = RdMisses
        out["writes"]         = Writes
        out["write_misses"]   = WrMisses
        out["second_misses"]  = S2Misses
        out["MM_Reads"]       = RdMisses+WrMisses
        out["MM_Writes"]      = MM_writes

        out["critical_path"]   = ex.critical_path_statistics_json(self.num_instr, _program.instruction_list, critical_path)
        return json.dumps(out)

_scheduler = Scheduler()
