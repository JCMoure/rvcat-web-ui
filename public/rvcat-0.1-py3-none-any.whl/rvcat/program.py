import json

global _program

class Instruction:

    def __init__(self) -> None:
        self.type     = ""
        self.oper     = ""
        self.size     = ""
        self.text     = ""
        self.destin   = ""
        self.source1  = ""
        self.source2  = ""
        self.source3  = ""
        self.constant = ""
        self.stride   = 1
        self.lanes    = 1
        self.latency  = 0
        self.ports    = 0
        self.addr     = 0    # value initialized when program is loaded
        self.byte_stride = 4 # value initialized when program is loaded

    def from_json(data: dict):
        instr = Instruction()
        instr.oper       = data.get("oper", "")
        instr.type       = data.get("type", "")
        instr.size       = data.get("size", "")
        instr.text       = data.get("text", "")
        instr.destin     = data.get("destin", "")
        instr.source1    = data.get("source1", "")
        instr.source2    = data.get("source2", "")
        instr.source3    = data.get("source3", "")
        instr.constant   = data.get("constant", "")
        instr.lanes      = data.get("lanes", 1)
        instr.stride     = data.get("stride", 1)
        instr.addr       = data.get("addr", 0)
        instr.byte_stride= data.get("byte_stride", 4)
        instr.latency    = data.get("latency", 0)
        instr.ports      = data.get("ports", 0)
        return instr

    def json(self) -> dict:
        return {
            "type":     self.type,
            "oper":     self.oper,
            "size":     self.size,
            "text":     self.text,
            "destin":   self.destin,
            "source1":  self.source1,
            "source2":  self.source2,
            "source3":  self.source3,
            "constant": self.constant,
            "lanes":    self.lanes,
            "stride":   self.stride,
            "latency":  self.latency,
            "ports":    self.ports
        }
    
class Process:

    def __init__(self) -> None:
        self.name     = ""
        self.dispatch = 1
        self.retire   = 1
        self.ROBsize  = 20 
        self.instruction_list = []
        self.mPenalty   = 1
        self.mIssueTime = 1
        self.sched      = "greedy"
        self.blksize    = 16
        self.nBlocks    = 0

    def from_json(data: dict):
        process = Process()
        process.name             = data.get("name", "")
        process.dispatch         = data.get("dispatch", 1)
        process.retire           = data.get("retire", 1)
        process.ROBsize          = data.get("ROBsize", 20)
        process.instruction_list = data.get("instruction_list", [])
        process.mPenalty         = data.get("mPenalty", 1) 
        process.mIssueTime       = data.get("mIssueTime", 1)
        process.sched            = data.get("sched", "greedy")
        process.blksize          = data.get("blksize", 16)
        process.nBlocks          = data.get("nBlocks", 0)
        return process

    def json(self) -> dict:
        return {
            "name":             self.name,
            "dispatch":         self.dispatch,
            "retire":           self.retire,
            "ROBsize":          self.ROBsize,
            "instruction_list": self.instruction_list,
            "mPenalty":         self.mPenalty,
            "mIssueTime":       self.mIssueTime,
            "sched":            self.sched,
            "blksize":          self.blksize,
            "nBlocks":          self.nBlocks
        }

class Program:

    def __init__(self) -> None:

        # data loaded/stored which do not change during execution
        self.n                = 0
        self.instruction_list = []

        # data generated when loading a new program. Do not need to save it
        self.variables    = [] # variable names (each appears only once, in program order)
        self.constants    = [] # constant values/variable names (only once, program order)
        self.read_only    = [] # list of read-only variable names (only once)
        self.loop_carried = [] # list of tuples of loop-carried variables: (producer_id,var_name)
        self.arrays       = [] # list of array variable names in program order

        self.inst_dependence_list = []  ## list of instruction data dependencies
        self.dependence_edges     = []  ## list of dependence offsets
        self.cyclic_paths         = []  # list of cyclic paths (a list of inst_ids)
        self.inst_cyclic          = []  # list of inst_ids in cyclic paths (only once)

    def __getitem__(self, i: int):
        return self.instruction_list[i%self.n]

    # Load JSON object containing program specification
    def load_instruction_list(self, instrs) -> None:

        self.instruction_list = []
        for instr_dict in instrs:
            self.instruction_list.append(Instruction.from_json(instr_dict))
        self.n            = len(self.instruction_list)
        self.loop_stride  = 1 # by default, loop stride is 1
        self.variables    = [] # variable names (each appears only once, in program order)
        self.constants    = [] # constant values/variable names (only once, program order)
        self.loop_carried = [] # index to list of variable names which are loop-carried
        self.read_only    = [] # index to list of variable names which are read-only
        self.arrays       = [] # list of array variable names in program order

        self.inst_dependence_list = []  ## list of instruction data dependencies
        # inst_dependence_list = [ i0, i1, i2 ... ]; 
        #       i0 = [ dep0, dep1, ...];   List of input dependencies, from 0 to 3
        #     dep0 = [ instID, varID / constID]; 
        #   instID = 0 to N-1  index of instruction generating input value
        #    varID = 0 to K-1  index of variable name representing input value
        #   instID = -1  means input value is constant
        #   instID = -3  means input value is read-only variable
        #  constID = 0 to C-1  index to constant name representing input constant

        Outs    = [] ## List of output variable names in program's instruction order
        Reads1  = [] ## List of  first input variable names in program's instruction order
        Reads2  = [] ## List of second input variable names in program's instruction order
        Reads3  = [] ## List of third output variable names in program's instruction order
        Consts  = [] ## List of constants in program's instruction order

        for inst in self.instruction_list:
            Outs.append  (inst.destin)
            Consts.append(inst.constant)
            Reads1.append(inst.source1)
            Reads2.append(inst.source2)
            Reads3.append(inst.source3)

        # List of variable names that are output of an instruction (appears only once)
        Outputs = list(set(Outs))  
        if "" in Outputs:
          Outputs.remove("")

        # List of variable names that are input of an instruction (appears only once)
        Inputs = list(set(Reads1+Reads2+Reads3))  
        if "" in Inputs:
          Inputs.remove("")

        # List of variable names (each appears only once, in program order)
        self.variables = list(set(Outputs+Inputs))
        if "" in self.variables:
          self.variables.remove("")

        # List of constant values / variable names (each appears only once)
        self.constants = list(set(Consts))
        if "" in self.constants:
          self.constants.remove("")
       
        # remove constants which are already a variable (this should not happen)
        setVars = set(self.variables)
        index = 0
        for c in self.constants:
          if c in setVars:
             self.constants.pop(index)
          else:
            index += 1

        # initialize list of producers for each variable as NONE
        producer_list = [-2 for _ in range(len(Outputs))]

        # analyze all instructions in program order to generate dependence info
        for inst_id in range(self.n):

            # create dependence list for intruction inst_id and append to program's dependence list
            dep_list = [] 
            self.inst_dependence_list.append(dep_list)

            const = Consts[inst_id]
            if const:  # register usage of this constant
                dep = [-1, self.constants.index(const)]
                dep_list.append(dep)

            source_var = Reads1[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            source_var = Reads2[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            source_var = Reads3[inst_id]
            if source_var:  # register dependence on this variable
                var_idx = self.variables.index(source_var)
                if source_var in Outputs:
                    out_idx  = Outputs.index(source_var)
                    prod_idx = producer_list[out_idx]
                else:  # read-only variable: acts as if it is a constant value
                    prod_idx = -3
                    self.read_only.append(source_var)
                dep = [prod_idx, var_idx]
                dep_list.append(dep)

            output_var = Outs[inst_id]
            if output_var:  # modify producer of this variable
                out_idx = Outputs.index(output_var)
                producer_list[out_idx] = inst_id

        # analyze all instructions in program order to solve loop-carried dependencies
        for inst_id in range(self.n):
            # obtain dependence list for intruction inst_id
            dep_list = self.inst_dependence_list[inst_id]
            for dep in dep_list:
                if dep[0] == -2: # dependence is pending to solve
                    source_var= self.variables[ dep[1] ]
                    out_idx   = Outputs.index(source_var)
                    prod_idx  = producer_list[out_idx]
                    dep[0] = prod_idx
                    self.loop_carried.append( (prod_idx, source_var) )

        # List of read-only variable names (each appears only once, in program order)
        self.read_only    = list(set(self.read_only))

        # List of tuples of loop-carried (producer, variable name) each appears only once
        self.loop_carried = list(set(self.loop_carried))

        self.generate_dependence_info()
        self.get_cyclic_paths()

        Insts = []
        for cyc_path in self.cyclic_paths:
          for iID in cyc_path:
            Insts.append  (iID)

        self.inst_cyclic = list(set(Insts))  
        # list of inst_ids in cyclic paths (only once)

        # get list of array variables in program order
        Arrays = []
        for inst in self.instruction_list:
            if inst.type == "MEM" or inst.type == "VMEM":
              ArrayName = inst.source2
              Arrays.append  (ArrayName)
            elif inst.type == "INT":  # if stride is not 1, then it defines the loop counter stride
              if inst.stride != 1:
                self.loop_stride= inst.stride

        # List of array variable names (each appears only once)
        self.arrays = list(set(Arrays))
        if "" in self.arrays:
          self.arrays.remove("")

    def assign_memory_addresses(self, N: int) -> None:
        # assign initial memory addresses and byte-stride to load/store instructions, 
        # for use in memory trace generation
        # for simplicity, we assign addresses to all array names in program order, starting from 0
        # accesses to an array determin the arrays size
        
        iterations = N // self.loop_stride  # number of loop iterations to execute

        init_addr = 0
        for arrayName in self.arrays:
            array_size = 0
            for inst in self.instruction_list:
                if inst.type == "MEM" or inst.type == "VMEM":
                    if (arrayName == inst.source2):
                        const = 0 if inst.constant == "" else int(inst.constant)
                        dataSize = 4 if inst.type == "word" else (8 if inst.type == "long" else 1)
                        inst.byte_stride = dataSize*inst.lanes*inst.stride
                        if inst.stride < 0: # if stride is negative, then it is a reverse access starting from the end of the array
                           inst.addr = init_addr + (N-const)*dataSize
                           last_addr = inst.addr + (iterations-1)*inst.byte_stride
                           array_size = max(array_size, inst.addr+dataSize*inst.lanes)
                        elif inst.stride > 0:  # if stride is positive, then it is a forward access starting from the beginning of the array
                           inst.addr = init_addr + const*dataSize
                           last_addr = inst.addr + (iterations-1)*inst.byte_stride
                           array_size = max(array_size, last_addr+dataSize*inst.lanes)
                        else:  # if stride is zero, then it is an offset starting from the beginning of the array
                           inst.addr = init_addr + const*dataSize
                           last_addr = inst.addr + inst.byte_stride
                           array_size = max(array_size, last_addr+dataSize*inst.lanes)

            init_addr += array_size  # assign next array to the next free address after current array
            
    def generate_dependence_info (self) -> None:

        # Used by execution scheduler to control data dependencies during execution
        # For each static instruction, list of dependent offsets 
        # offset = positive number to subtract to my instruction ID to find dependent intr. ID

        self.dependence_edges = []  

        for inst_id in range(self.n):
            offsets = []
            for dep in self.inst_dependence_list[inst_id]:
                dep_id = dep[0]  # ID of instruction providing data to instruction inst_id
                if dep_id >= 0:  # is a data dependence
                  if dep_id >= inst_id: # loop carried dependence
                    offset = inst_id - dep_id + self.n
                  else:
                    offset = inst_id - dep_id
                  offsets.append(offset)

            self.dependence_edges.append(offsets)

    def get_cyclic_paths(self) -> None:

        # return list of cyclic dependence paths: [[3, 3], [2, 0, 2]],
        # numbers are instr-IDs: same ID appears at begin & end

        start_instrs = []

        for inst_id in range(self.n):
            some_prev_dependence = False
            for dep in self.inst_dependence_list[inst_id]:
                if (dep[0] >= 0) and (dep[0] < inst_id):
                    some_prev_dependence = True
            if not some_prev_dependence:
                start_instrs.append(inst_id)

        # dependency graph in reverse order: from producer to consumer
        dependency_graph = {i:[] for i in range(self.n)}
        for inst_id in range(self.n):
            for dep in self.inst_dependence_list[inst_id]:
                if (dep[0] >= 0):
                    dependency_graph[dep[0]].append(inst_id)

        cyc_paths = []
        paths     = [ [i]  for i in start_instrs]
        visited   = { i:[] for i in range(self.n)}

        while paths:
            path = paths.pop()
            last = path[-1]
            for dep_id in dependency_graph[last]:
                if dep_id not in visited[last]:
                    paths.append(path+[dep_id])
                    visited[last].append(dep_id)
                else:
                    if len(set(path)) != len(path):  # some inst_id appears twice
                        path = path[path.index(last):]
                        if path not in cyc_paths:
                            cyc_paths.append(path)

        self.cyclic_paths = []
        for path in cyc_paths:
            path = path[:-1]                 # remove last element (repeated as the first one)
            min_val   = min(path)            # find minimum value
            min_index = path.index(min_val)  # find position of minimum value
            path = path[min_index:]+path[:min_index+1]
            self.cyclic_paths.append(path)

    def get_critical_latencies (self):
        max_latency    = 0   # maximum latency per iteration
        min_iters      = 0   # minimum number of iterations for cyclic path
        path_latencies = []  # (latency,iters) of cyclic paths

        recurrent_paths = self.cyclic_paths
        for path in recurrent_paths:
            latency = sum( self.instruction_list[i].latency for i in path[:-1] )
            iters   = sum( a >= b       for a,b in zip(path[:-1], path[1:]) )
            latency_iter = latency / iters
            path_latencies.append((latency, iters))
            if latency_iter > max_latency:
                max_latency = latency_iter
            min_iters = max( iters, min_iters )

        return (max_latency, min_iters, path_latencies)

    def show_memory_trace(self) -> str:
        out = "............................. Memory Trace Description ..........................."
        out += "\n...............................................................................\n\n"
        return out

    def show_graphviz(  self, 
                        instrs       = None,
                        num_iters    = 0,
                        show_internal= False,
                        show_latency = False,
                        show_small   = False,
                        show_full    = False 
                        ) -> str:
      
        def escape_html(text: str) -> str:
            """Escape HTML special characters for Graphviz HTML-like labels."""
            return text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;').replace('"', '&quot;')

        colors = ["lightblue", "greenyellow", "lightyellow", 
                  "lightpink", "lightgrey",   "lightcyan", "lightcoral"]

        self.load_instruction_list(instrs)

        recurrent_paths = self.cyclic_paths

        # max_latency    = maximum latency per iteration
        # min_iters      = minimum number of iterations for cyclic path
        # path_latencies = [ (latency,iters), (,) .. ]  of cyclic paths
        max_latency, min_iters, path_latencies = self.get_critical_latencies() 

        max_iters = max (min_iters, num_iters)

        out  = "digraph \"Data Dependence Graph\" {\n  rankdir=\"LR\"; splines=spline; newrank=true;\n"
        out += "  edge [fontname=\"courier\"; color=black; penwidth=1.5; fontcolor=blue];\n"

        # generate clusters of nodes: one cluster per loop iteration
        for iter_id in range(1, max_iters+1):
            out += f" subgraph cluster_{iter_id} "
            out +=  "{\n  style=\"filled,rounded\"; color=blue; "
            out += f"tooltip=\"Loop Iteration #{iter_id}\"; fillcolor={colors[iter_id-1]};\n"
            out +=  "  node [style=filled, shape=rect, fillcolor=lightgrey,"
            out +=  " margin=\"0.05,0\", fontname=\"courier\"];\n"

            for inst_id in range(self.n):
                if show_internal or (inst_id in self.inst_cyclic):
                  lat = self.instruction_list[inst_id].latency
                  txt = escape_html(self.instruction_list[inst_id].text)
                  out += f"  i{iter_id}s{inst_id} ["
                  out +=  "label=<<B>"
                  if show_latency:
                    out += f"<FONT COLOR=\"red\">({lat})</FONT> "
                  out += f"{inst_id}"
                  if show_small:
                    out += f"</B>>, tooltip=\"{txt}\"];\n"
                  else:
                    out += f": {txt}</B>>,tooltip=\"instruction\"];\n"

            out +=  "}\n"

    
        # generate cluster of input variables
        out += " subgraph inVAR {\n"
        out += "  node[style=box, color=invis, fixedsize=false, fontname=\"courier\"];\n"

        if show_full and show_internal:
          for const_id in range( len(self.constants) ):
             var = self.constants[const_id]
             out += f"  Const{const_id} [label=<<B>{var}</B>>, tooltip=\"constant\", fontcolor=grey];\n"

        if show_full and show_internal:
          for RdOnly_id in range( len(self.read_only) ):
             var = self.read_only[RdOnly_id]
             out += f"  RdOnly{RdOnly_id} [label=<<B>{var}</B>>, tooltip=\"read-only\", fontcolor=green];\n"

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,var) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"  LoopCar{LoopCar_id} [label=<<B>{var}</B>>, tooltip=\"loop-recurrent\", "
               if cyclic:
                   out += "fontcolor=red];\n"
               else:
                   out += "fontcolor=blue];\n"

        out += " }\n"

        out += " { rank=min; "
                
        if show_full and show_internal:
          for const_id in range( len(self.constants) ):
             out += f"Const{const_id}; "

        if show_full and show_internal:
          for RdOnly_id in range( len(self.read_only) ):
             out += f"RdOnly{RdOnly_id}; "

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,_) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
             out += f"LoopCar{LoopCar_id}; "

        out += " }\n\n"


        # generate cluster of output variables
        out += " subgraph outVAR {\n"
        out += "  node [style=box, color=invis, fontcolor=red, fixedsize=false, fontname=\"courier\"];\n"

        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,var) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"  OutCar{LoopCar_id} "
               if cyclic:
                   out += f"[label=<<B>{var}"
                   if show_latency:
                      # Find all paths containing inst_id and get their ratios, then take the max
                      paths_with_inst = [(p, path_latencies[p]) for p in range(len(recurrent_paths)) if inst_id in recurrent_paths[p]]
                      (lat, iters) = max(paths_with_inst, key=lambda x: x[1][0] / x[1][1] if x[1][1] != 0 else float('inf'))[1]
                      if iters==1:
                        out += f" : <FONT COLOR=\"blue\">{lat} cycles/iter</FONT>"
                      else:
                        out += f" : <FONT COLOR=\"blue\">{lat}/{iters}= {lat/iters} cycles/iter</FONT>"
                   out += f"</B>>, tooltip=\"cyclic path\"];\n"
               else:
                   out += f"[label=<<B>{var}</B>>, tooltip=\"not cyclic\", fontcolor=blue];\n"
        out += " }\n"

        out += " { rank=max; "
        for LoopCar_id in range( len(self.loop_carried) ):
           (inst_id,_) = self.loop_carried[LoopCar_id]
           cyclic = inst_id in self.inst_cyclic
           if show_internal or cyclic:
               out += f"OutCar{LoopCar_id}; "

        out += " }\n\n"


        # generate dependence links: initial and intermediate
        for iter_id in range(1, max_iters+1):
          for inst_id in range(self.n):
            for dep in self.inst_dependence_list[inst_id]:

              i_id = dep[0]
              var  = dep[1]

              if i_id == -1:  # inst_id depends on Constant
                if show_full and show_internal:
                  out += f"  Const{var} -> i{iter_id}s{inst_id}[color=grey,tooltip=\"depends on constant\"];\n"
                continue

              if i_id == -3:  # inst_id depends on Read-Only variable
                if show_full and show_internal:
                  label  = self.variables[var]
                  RdOnly_id = self.read_only.index(label)
                  out += f"  RdOnly{RdOnly_id} -> i{iter_id}s{inst_id}[color=green,tooltip=\"depends on read-only variable\"];\n"
                continue

              # inst_id depends on "normal" variable
              # Check if current dependence is a part of a cyclical path
              in_cyclic   = inst_id in self.inst_cyclic
              out_cyclic  = i_id    in self.inst_cyclic 
              is_recurrent= in_cyclic and out_cyclic

              if is_recurrent:
                  arrow = "color=red, penwidth=2.0"
              else:
                  arrow = ""

              if inst_id > i_id: ## Not loop-carried
                  in_var = f"i{iter_id}s{i_id}"
                  if show_small:
                    label = ""
                  else:
                    label = self.variables[var]
              else:   ## Loop-carried
                  if iter_id == 1: # first loop iteration
                      var = self.variables[var]
                      for LoopCar_id in range( len(self.loop_carried) ):
                          (_,lc_var) = self.loop_carried[LoopCar_id]
                          if var == lc_var:
                             in_var = f"LoopCar{LoopCar_id}"
                             break
                      label  = ""
                  else:
                      in_var = f"i{iter_id-1}s{i_id}"
                      if show_small:
                          label = ""
                      else:
                          label  = self.variables[var]

              if is_recurrent:
                  out += f"  {in_var} -> i{iter_id}s{inst_id} [label=\"{label}\","
                  out += f" labeltooltip=\"dependence variable: {label}\","
                  out += f" tooltip=\"dependence on cyclical path\", {arrow}];\n"
              elif show_internal:
                  out += f"  {in_var} -> i{iter_id}s{inst_id} [label=\"{label}\","
                  out += f" labeltooltip=\"dependence variable: {label}\","
                  out += f" tooltip=\"not on cyclical path\", {arrow}];\n"

        # generate dependence links to loop-carried variables in final iteration
        for LoopCar_id in range( len(self.loop_carried) ):
           (prod_id,_) = self.loop_carried[LoopCar_id]
           cyclic      = prod_id in self.inst_cyclic
           if cyclic:
               out += f"  i{max_iters}s{prod_id} -> OutCar{LoopCar_id}[color=red, penwidth=2.0,tooltip=\"cyclic output dependence\"];\n"
           elif show_internal:
               out += f"  i{max_iters}s{prod_id} -> OutCar{LoopCar_id}[color=blue, penwidth=2.0, tooltip=\"non-cyclic output dependence\"];\n"

        return out + "}\n"

    def get_performance_analysis(self, processJSON) -> dict:

        process = Process.from_json(processJSON)
        self.load_instruction_list(process.instruction_list)

        analysis = { "name": getattr(process, 'name', '') }
        
        dw = process.dispatch
        rw = process.retire

        all_ports = 0
        for instr in self.instruction_list:
            all_ports |= instr.ports

        # list of used ports and number of used ports
        used_ports = [i for i in range(32) if (all_ports >> i) & 1]
        n_ports = len(used_ports)

        dw_cycles = self.n / dw
        rw_cycles = self.n / rw

        # max_latency    = maximum latency per iteration
        max_latency, *_ = self.get_critical_latencies() 

        # All combinations of this ports
        from itertools import combinations

        port_cycles = 0
        for r in range(1, n_ports + 1):
            for subset in combinations(used_ports, r):
                mask = 0
                for p in subset:
                    mask |= (1 << p)

                uses = 0
                for instr in self.instruction_list:
                    instr_mask = instr.ports
                    if (mask & instr_mask) == instr_mask:
                        uses += 1

                cycles = uses / len(subset)
                if cycles > port_cycles:
                    port_cycles = cycles

        max_cycles = max(port_cycles, dw_cycles, rw_cycles)

        analysis["LatencyTime"]=    max_latency 
        analysis["ThroughputTime"]= max_cycles

        cycles_limit = max_cycles
        if (max_latency > max_cycles):
            analysis["performance-bound"] = "LATENCY"
            cycles_limit = max_latency
        elif (max_latency < max_cycles):
            analysis["performance-bound"] = "THROUGHPUT"
        else:
            analysis["performance-bound"] = "LATENCY+THROUGHPUT"
        
        analysis["BestTime"] = cycles_limit
        analysis["Throughput-Bottlenecks"] = []

        if dw_cycles == max_cycles:
           text = f"Dispatch: {self.n} instr. per iter. / {dw} instr. per cycle = {dw_cycles:0.2f}"
           analysis["Throughput-Bottlenecks"].append(text)

        if rw_cycles == max_cycles:
           text = f"Retire: {self.n} instr. per iter. / {rw} instr. per cycle = {rw_cycles:0.2f}"
           analysis["Throughput-Bottlenecks"].append(text)

        for r in range(1, n_ports + 1):
            for subset in combinations(used_ports, r):
                mask = 0
                for p in subset:
                    mask |= (1 << p)

                uses = 0
                inst_str= ""
                for i in range(self.n):
                    instr = self.instruction_list[i]
                    instr_mask = instr.ports
                    if (mask & instr_mask) == instr_mask:
                        uses += 1
                        inst_str += f"{i},"

                cycles = uses / len(subset)
                if cycles == max_cycles:
                    port_str = ""
                    mask_bit=1
                    for j in range(n_ports):
                        if mask_bit & mask == mask_bit:
                            port_str += f"P{j}+"
                        mask_bit *= 2

                    text = f"Ports: {port_str[:-1]}, Instr.: {inst_str[:-1]} -->"
                    text+= f"{uses} instr. per iter. / {len(subset)} instr. per cycle = {cycles:0.2f}"
                    analysis["Throughput-Bottlenecks"].append(text)

        return json.dumps(analysis, indent=2)

_program = Program()
